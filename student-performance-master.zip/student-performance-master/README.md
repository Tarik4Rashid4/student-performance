

Citation: Rashid TA, Abbas DK, Turel YK (2019) A multi hidden recurrent neural network with a modified grey wolf optimizer. PLoS ONE 14(3): e0213237. https://doi.org/10.1371/journal.pone.0213237